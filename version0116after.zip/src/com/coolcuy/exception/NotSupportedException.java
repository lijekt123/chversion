package com.coolcuy.exception;

public class NotSupportedException extends RuntimeException{
	
}
