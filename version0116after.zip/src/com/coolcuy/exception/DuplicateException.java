package com.coolcuy.exception;

public class DuplicateException extends RuntimeException{

}
