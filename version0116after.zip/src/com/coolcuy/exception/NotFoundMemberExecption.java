package com.coolcuy.exception;

public class NotFoundMemberExecption extends RuntimeException {
	
}
