package com.coolcuy.exception;

public class NotFoundCardExecption extends RuntimeException {

}
